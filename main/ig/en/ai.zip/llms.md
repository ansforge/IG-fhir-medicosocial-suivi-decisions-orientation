# ans.fhir.fr.sdo#4.0.7: Médicosocial - Suivi Décisions Orientation(en)

## Pages

* [Accueil](index.md)
* [OID MDPH associés à la spécification](annexes_OID_MDPH.md)
* [Flux 4 - StatutPersonneOrientee](st_flux4.md)
* [Téléchargements et usages](downloads.md)
* [Flux 2 - Accord](st_flux2.md)
* [Nomenclature précisions de l'orientation](annexes_Nomenclatures_precision.md)
* [Diagramme de Séquence SI-MDPH / SI-SDO / SI-ESMS](annexes_Diagramme.md)
* [Artifacts Summary](artifacts.md)
* [Sécurité](securite.md)
* [Nomenclatures de référence associées aux spécifications](annexes_Nomenclature.md)
* [Flux 5 - Recherche et résultats de statuts](st_flux5.md)
* [Contenu du dossier](contenu_dossier.md)
* [Solutions de tests](tests.md)
* [Ressources FHIR](ressource_fhir.md)
* [Ressources CDA](ressource_cda.md)
* [Flux 1 - Recherche et consultation de personne orientée et décision](st_flux1.md)
* [Flux 3 - Recherche et résultats d'évaluation](st_flux3.md)
* [Historique des changements](changes.md)
* [Glossaire associé à la spécification](annexes_Glossaire.md)
* [Correspondance entre objets métier et ressources du standard HL7 FHIR](correspondance_objet.md)
* [Synthèse des flux](synthese_flux.md)

## Resources

### CodeSystems

* [InputTaskSDOCodeSystem](CodeSystem-input-task-sdo-codesystem.md)

### ValueSets

* [DocumentReferenceTypeESMSValueSet](ValueSet-type-document-reference-esms-valueset.md)

### Resource Profiles

* [ESMSBundleResultatRechercheDecisionEvaluation](StructureDefinition-esms-bundle-resultat-recherche-decision-evaluation.md)
* [ESMSBundleResultatRechercheNotificationESMS](StructureDefinition-esms-bundle-resultat-recherche-notification-esms.md)
* [ESMSConsent](StructureDefinition-esms-consent.md)
* [ESMSDocumentReference](StructureDefinition-esms-document-reference.md)
* [ESMSTask](StructureDefinition-esms-task.md)

### CapabilityStatements

* [SI-ESMS-Consommateur](CapabilityStatement-ESMSConsommateur.md)
* [SI-ESMS-Producteur](CapabilityStatement-ESMSProducteur.md)
* [SI-SdO-Gestionnaire](CapabilityStatement-gestionnaire-sdo.md)

### ImplementationGuides

* [Médicosocial - Suivi Décisions Orientation](ImplementationGuide-ans.fhir.fr.sdo.md)

### Examples

* [exemple-bundle-resultat-recherche-decision-evaluation-elements (Bundle)](Bundle-exemple-bundle-resultat-recherche-decision-evaluation-elements.md)
* [exemple-bundle-resultat-recherche-decision-evaluation (Bundle)](Bundle-exemple-bundle-resultat-recherche-decision-evaluation.md)
* [exemple-esms-bundle-resultat-recherche-notifications-esms (Bundle)](Bundle-exemple-esms-bundle-resultat-recherche-notifications-esms.md)
* [exemple-consent (Consent)](Consent-exemple-consent.md)
* [exemple-esms-document-reference (DocumentReference)](DocumentReference-exemple-esms-document-reference.md)
* [exemple-esms-task (Task)](Task-exemple-esms-task.md)
