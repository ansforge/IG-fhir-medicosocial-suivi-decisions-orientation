# InputTaskSDOCodeSystem - Médicosocial - Suivi Décisions Orientation v4.0.6

## CodeSystem: InputTaskSDOCodeSystem 

 
Code System pour la définition des éléments spécifiques de input dans ressource ESMSTask 

This Code system is referenced in the definition of the following value sets:

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "input-task-sdo-codesystem",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
  "version" : "4.0.6",
  "name" : "InputTaskSDOCodeSystem",
  "title" : "InputTaskSDOCodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-25T12:35:53+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Code System pour la définition des éléments spécifiques de input dans ressource ESMSTask",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "caseSensitive" : true,
  "compositional" : false,
  "content" : "complete",
  "count" : 17,
  "concept" : [{
    "code" : "idNat_Struct",
    "display" : "idNat_Struct",
    "definition" : "Identifiant de l'ESMS accueillant l'individu en situation de handicap. Cet identifiant est obtenu par la concaténation du type d'identifiant national de structure (provenant de la nomenclature TRE_G07-TypeIdentifiantStructure) et de l'identifiant de la structure: ** 1 + N° FINESS (entité juridique et entité géographique indéterminées);** 3 + N° SIRET"
  },
  {
    "code" : "nomESMS",
    "display" : "nomESMS",
    "definition" : "Permet de définir le nom de l’ESMS"
  },
  {
    "code" : "statutESMS",
    "display" : "statutESMS",
    "definition" : "Statut de l’usager dans l'ESMS"
  },
  {
    "code" : "motifESMS",
    "display" : "motifESMS",
    "definition" : "Permet de définir le motif associé au statut de l’usager dans l’ESMS. Motifs obligatoires pour certains statuts suivant la table : https://mos.esante.gouv.fr/NOS/ASS_A32-StatutMotifPersonnePriseCharge/ASS_A32-StatutMotifPersonnePriseCharge.pdf"
  },
  {
    "code" : "dateStatutESMS",
    "display" : "dateStatutESMS",
    "definition" : "La spécification fonctionnelle des échanges (https://esante.gouv.fr/volet-si-esms-viatrajectoire-module-ph) donne la signification de cette date par rapport au statut ESMS"
  },
  {
    "code" : "idUnite",
    "display" : "idUnite",
    "definition" : "Identifiant de l'unité qui correspond à l’identifiant de l'organisation interne, unique et persistant au niveau national, et généré par une instance régionale du ROR (pour plus de précision, voir la spécification « ANS ROR - Modèle Exposition"
  },
  {
    "code" : "nomUnite",
    "display" : "nomUnite",
    "definition" : "Nom de l'unité"
  },
  {
    "code" : "categorieOrganisation",
    "display" : "categorieOrganisation",
    "definition" : "Permet de définir la catégorie d’organisation qui caractérise la nature particulière de l’offre de santé portée par l'unité"
  },
  {
    "code" : "temporaliteAccueil",
    "display" : "temporaliteAccueil",
    "definition" : "Permet de définir la fréquence d'accueil lors d'une prise en charge en ESMS"
  },
  {
    "code" : "accueilSequentiel",
    "display" : "accueilSequentiel",
    "definition" : "Permet de définir l’accueil séquentiel"
  },
  {
    "code" : "modePriseCharge",
    "display" : "modePriseCharge",
    "definition" : "Permet de définir le mode de prise en charge"
  },
  {
    "code" : "statutUnite",
    "display" : "statutUnite",
    "definition" : "Statut de la personne orientée au niveau de l’unité, définis dans le cadre fonctionnel du système d'information de suivi des orientations de la CNSA"
  },
  {
    "code" : "dateStatutUnite",
    "display" : "dateStatutUnite",
    "definition" : "La spécification fonctionnelle des échanges (https://esante.gouv.fr/volet-si-esms-viatrajectoire-module-ph) donne la signification de cette date par rapport au statut de l’unité"
  },
  {
    "code" : "motifUnite",
    "display" : "motifUnite",
    "definition" : "Permet de définir le motif de sortie ou d’admission impossible"
  },
  {
    "code" : "typeDroitPrestation",
    "display" : "typeDroitPrestation",
    "definition" : "Permet de définir le type de droit et prestation caractérisant la décision d'orientation."
  },
  {
    "code" : "idDecision",
    "display" : "idDecision",
    "definition" : "Permet de définir l’identifiant de la décision unique au sein de la MDPH"
  },
  {
    "code" : "idNat_Decision",
    "display" : "idNat_Decision",
    "definition" : "Identifiant technique national de la décision, généré par ViaTrajectoire. Cet identifiant unique est retourné dans le Flux 1 par ViaTrajectoire à la MDPH lorsque la décision est créée dans le SI-SdO."
  }]
}

```
