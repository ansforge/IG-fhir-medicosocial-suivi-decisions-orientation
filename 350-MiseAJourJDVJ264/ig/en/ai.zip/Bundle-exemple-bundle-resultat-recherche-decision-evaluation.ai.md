# exemple-bundle-resultat-recherche-decision-evaluation - Médicosocial - Suivi Décisions Orientation v4.0.6

## Example Bundle: exemple-bundle-resultat-recherche-decision-evaluation



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "exemple-bundle-resultat-recherche-decision-evaluation",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-bundle-resultat-recherche-decision-evaluation"]
  },
  "type" : "searchset",
  "entry" : [{
    "fullUrl" : "https://example.com/base/DocumentReference/exemple-esms-documentreference-1-in-bundle",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "exemple-esms-documentreference-1-in-bundle",
      "meta" : {
        "lastUpdated" : "2023-01-26T16:46:48.054+00:00",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-document-reference"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"DocumentReference_exemple-esms-documentreference-1-in-bundle\"> </a><p class=\"res-header-id\"><b>Narratif généré : RéférenceDocument exemple-esms-documentreference-1-in-bundle</b></p><a name=\"exemple-esms-documentreference-1-in-bundle\"> </a><a name=\"hcexemple-esms-documentreference-1-in-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Dernière mise à jour : 2023-01-26 16:46:48+0000</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-esms-document-reference.html\">ESMSDocumentReference</a></p></div><p><b>identifier</b>: idDecision1 (utilisation : usual, ), idNat_Decision1 (utilisation : official, )</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes :{http://loinc.org 57830-2}\">Admission request Document</span></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Language</b></td><td><b>Data</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td>Français</td><td><code>SGVsbG8gd29ybGQ=</code></td><td>Document Individu et décision</td></tr></table></blockquote></div></div>"
      },
      "identifier" : [{
        "use" : "usual",
        "value" : "idDecision1"
      },
      {
        "use" : "official",
        "value" : "idNat_Decision1"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "57830-2",
          "display" : "Admission request Document"
        }]
      },
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "language" : "fr",
          "data" : "SGVsbG8gd29ybGQ=",
          "title" : "Document Individu et décision"
        }
      }]
    }
  },
  {
    "fullUrl" : "https://example.com/base/DocumentReference/exemple-esms-documentreference-2-in-bundle",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "exemple-esms-documentreference-2-in-bundle",
      "meta" : {
        "lastUpdated" : "2019-12-08T10:07:46.748+00:00",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-document-reference"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"DocumentReference_exemple-esms-documentreference-2-in-bundle\"> </a><p class=\"res-header-id\"><b>Narratif généré : RéférenceDocument exemple-esms-documentreference-2-in-bundle</b></p><a name=\"exemple-esms-documentreference-2-in-bundle\"> </a><a name=\"hcexemple-esms-documentreference-2-in-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Dernière mise à jour : 2019-12-08 10:07:46+0000</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-esms-document-reference.html\">ESMSDocumentReference</a></p></div><p><b>identifier</b>: idDecision2 (utilisation : usual, ), idNat_Decision2 (utilisation : official, )</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes :{http://loinc.org 57830-2}\">Admission request Document</span></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Language</b></td><td><b>Data</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td>Français</td><td><code>SGVsbG8gd29ybGQ=</code></td><td>Document Individu et décision</td></tr></table></blockquote></div></div>"
      },
      "identifier" : [{
        "use" : "usual",
        "value" : "idDecision2"
      },
      {
        "use" : "official",
        "value" : "idNat_Decision2"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "57830-2",
          "display" : "Admission request Document"
        }]
      },
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "language" : "fr",
          "data" : "SGVsbG8gd29ybGQ=",
          "title" : "Document Individu et décision"
        }
      }]
    }
  }]
}

```
