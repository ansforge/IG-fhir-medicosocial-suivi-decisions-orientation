# ESMSBundleResultatRechercheDecisionEvaluation - Médicosocial - Suivi Décisions Orientation v4.0.6

## Resource Profile: ESMSBundleResultatRechercheDecisionEvaluation 

 
Profil ESMS créé dans le contexte du suivi des orientations pour transporter les documents répondant à une recherche de decision ou d’évaluation. 

**Usages:**

* Examples for this Profile: [Bundle/exemple-bundle-resultat-recherche-decision-evaluation-elements](Bundle-exemple-bundle-resultat-recherche-decision-evaluation-elements.md) and [Bundle/exemple-bundle-resultat-recherche-decision-evaluation](Bundle-exemple-bundle-resultat-recherche-decision-evaluation.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.fhir.fr.sdo|current/StructureDefinition/StructureDefinition-esms-bundle-resultat-recherche-decision-evaluation.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-esms-bundle-resultat-recherche-decision-evaluation.csv), [Excel](../StructureDefinition-esms-bundle-resultat-recherche-decision-evaluation.xlsx), [Schematron](../StructureDefinition-esms-bundle-resultat-recherche-decision-evaluation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "esms-bundle-resultat-recherche-decision-evaluation",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-bundle-resultat-recherche-decision-evaluation",
  "version" : "4.0.6",
  "name" : "ESMSBundleResultatRechercheDecisionEvaluation",
  "status" : "active",
  "date" : "2026-06-26T14:31:02+00:00",
  "publisher" : "ANS",
  "contact" : [{
    "name" : "ANS",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Profil ESMS créé dans le contexte du suivi des orientations pour transporter les documents répondant à une recherche de decision ou d’évaluation.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Bundle",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.type",
      "path" : "Bundle.type",
      "patternCode" : "searchset"
    },
    {
      "id" : "Bundle.entry.resource",
      "path" : "Bundle.entry.resource",
      "short" : "A Document to be retrieved",
      "definition" : "A Document to be retrieved (either a Decision or an Evaluation)",
      "min" : 1,
      "type" : [{
        "code" : "DocumentReference",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-document-reference"]
      }]
    }]
  }
}

```
