# exemple-esms-bundle-resultat-recherche-notifications-esms - Médicosocial - Suivi Décisions Orientation v4.0.6

## Exemple Bundle: exemple-esms-bundle-resultat-recherche-notifications-esms



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "exemple-esms-bundle-resultat-recherche-notifications-esms",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-bundle-resultat-recherche-notification-esms"]
  },
  "type" : "searchset",
  "entry" : [{
    "fullUrl" : "https://example.com/base/Task/exemple-esms-task-1-in-bundle",
    "resource" : {
      "resourceType" : "Task",
      "id" : "exemple-esms-task-1-in-bundle",
      "meta" : {
        "lastUpdated" : "2019-09-26T16:46:48.054+00:00",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-task"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"Task_exemple-esms-task-1-in-bundle\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task exemple-esms-task-1-in-bundle</b></p><a name=\"exemple-esms-task-1-in-bundle\"> </a><a name=\"hcexemple-esms-task-1-in-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Dernière mise à jour : 2019-09-26 16:46:48+0000</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-esms-task.html\">ESMSTask</a></p></div><p><b>status</b>: Completed</p><p><b>intent</b>: plan</p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idNat_Struct}\">idNat_Struct</span></p><p><b>value</b>: idNat_Struct</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem nomESMS}\">nomESMS</span></p><p><b>value</b>: value nomESMS</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idDecision}\">idDecision</span></p><p><b>value</b>: idDecision</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idNat_Decision}\">idNat_Decision</span></p><p><b>value</b>: idNat_Decision</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem statutESMS}\">statutESMS</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R357-StatutPersonnePriseCharge/FHIR/TRE-R357-StatutPersonnePriseCharge 48}\">Usager sorti</span></p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem dateStatutESMS}\">dateStatutESMS</span></p><p><b>value</b>: 2012-10-25</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idUnite}\">idUnite</span></p><p><b>value</b>: idUnite</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem nomUnite}\">nomUnite</span></p><p><b>value</b>: test NomUnite</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem categorieOrganisation}\">categorieOrganisation</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R244-CategorieOrganisation/FHIR/TRE-R244-CategorieOrganisation 01}\">Appartement thérapeutique</span></p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem temporaliteAccueil}\">temporaliteAccueil</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R240-TemporaliteAccueil/FHIR/TRE-R240-TemporaliteAccueil 01}\">Temporaire</span></p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem accueilSequentiel}\">accueilSequentiel</span></p><p><b>value</b>: true</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem modePriseCharge}\">modePriseCharge</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R213-ModePriseEnCharge/FHIR/TRE-R213-ModePriseEnCharge 47}\">Accueil de jour</span></p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem statutUnite}\">statutUnite</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R357-StatutPersonnePriseCharge/FHIR/TRE-R357-StatutPersonnePriseCharge 188}\">Fin de prise en charge</span></p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem dateStatutUnite}\">dateStatutUnite</span></p><p><b>value</b>: 2021-10-25</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem motifUnite}\">motifUnite</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R358-MotifStatutPersonnePriseCharge/FHIR/TRE-R358-MotifStatutPersonnePriseCharge 89}\">L'usager ne souhaite plus être pris en charge par l'ESMS</span></p></blockquote></div></div>"
      },
      "status" : "completed",
      "intent" : "plan",
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idNat_Struct"
          }]
        },
        "valueIdentifier" : {
          "value" : "idNat_Struct"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "nomESMS"
          }]
        },
        "valueString" : "value nomESMS"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idDecision"
          }]
        },
        "valueIdentifier" : {
          "value" : "idDecision"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idNat_Decision"
          }]
        },
        "valueIdentifier" : {
          "value" : "idNat_Decision"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "statutESMS"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R357-StatutPersonnePriseCharge/FHIR/TRE-R357-StatutPersonnePriseCharge",
            "code" : "48",
            "display" : "Usager sorti"
          }]
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "dateStatutESMS"
          }]
        },
        "valueDate" : "2012-10-25"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idUnite"
          }]
        },
        "valueIdentifier" : {
          "value" : "idUnite"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "nomUnite"
          }]
        },
        "valueString" : "test NomUnite"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "categorieOrganisation"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R244-CategorieOrganisation/FHIR/TRE-R244-CategorieOrganisation",
            "code" : "01",
            "display" : "Appartement thérapeutique"
          }]
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "temporaliteAccueil"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R240-TemporaliteAccueil/FHIR/TRE-R240-TemporaliteAccueil",
            "code" : "01",
            "display" : "Temporaire"
          }]
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "accueilSequentiel"
          }]
        },
        "valueBoolean" : true
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "modePriseCharge"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R213-ModePriseEnCharge/FHIR/TRE-R213-ModePriseEnCharge",
            "code" : "47",
            "display" : "Accueil de jour"
          }]
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "statutUnite"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R357-StatutPersonnePriseCharge/FHIR/TRE-R357-StatutPersonnePriseCharge",
            "code" : "188",
            "display" : "Fin de prise en charge"
          }]
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "dateStatutUnite"
          }]
        },
        "valueDate" : "2021-10-25"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "motifUnite"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R358-MotifStatutPersonnePriseCharge/FHIR/TRE-R358-MotifStatutPersonnePriseCharge",
            "code" : "89",
            "display" : "L'usager ne souhaite plus être pris en charge par l'ESMS"
          }]
        }
      }]
    }
  },
  {
    "fullUrl" : "https://example.com/base/Task/exemple-esms-task-2-in-bundle",
    "resource" : {
      "resourceType" : "Task",
      "id" : "exemple-esms-task-2-in-bundle",
      "meta" : {
        "lastUpdated" : "2019-12-08T10:07:46.748+00:00",
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/sdo/StructureDefinition/esms-task"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"Task_exemple-esms-task-2-in-bundle\"> </a><p class=\"res-header-id\"><b>Narratif généré : Task exemple-esms-task-2-in-bundle</b></p><a name=\"exemple-esms-task-2-in-bundle\"> </a><a name=\"hcexemple-esms-task-2-in-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Dernière mise à jour : 2019-12-08 10:07:46+0000</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-esms-task.html\">ESMSTask</a></p></div><p><b>status</b>: Completed</p><p><b>intent</b>: plan</p><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idNat_Struct}\">idNat_Struct</span></p><p><b>value</b>: value idNat_Struct</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem nomESMS}\">nomESMS</span></p><p><b>value</b>: value nomESMS</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idDecision}\">idDecision</span></p><p><b>value</b>: idDecision</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem idNat_Decision}\">idNat_Decision</span></p><p><b>value</b>: idNat_Decision</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem statutESMS}\">statutESMS</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R357-StatutPersonnePriseCharge/FHIR/TRE-R357-StatutPersonnePriseCharge 41}\">Contact effectué</span></p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes :{https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem motifESMS}\">motifESMS</span></p><p><b>value</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R358-MotifStatutPersonnePriseCharge/FHIR/TRE-R358-MotifStatutPersonnePriseCharge 152}\">L'usager a visité l'ESMS</span></p></blockquote></div></div>"
      },
      "status" : "completed",
      "intent" : "plan",
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idNat_Struct"
          }]
        },
        "valueIdentifier" : {
          "value" : "value idNat_Struct"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "nomESMS"
          }]
        },
        "valueString" : "value nomESMS"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idDecision"
          }]
        },
        "valueIdentifier" : {
          "value" : "idDecision"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "idNat_Decision"
          }]
        },
        "valueIdentifier" : {
          "value" : "idNat_Decision"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "statutESMS"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R357-StatutPersonnePriseCharge/FHIR/TRE-R357-StatutPersonnePriseCharge",
            "code" : "41",
            "display" : "Contact effectué"
          }]
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "https://interop.esante.gouv.fr/ig/fhir/sdo/CodeSystem/input-task-sdo-codesystem",
            "code" : "motifESMS"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R358-MotifStatutPersonnePriseCharge/FHIR/TRE-R358-MotifStatutPersonnePriseCharge",
            "code" : "152",
            "display" : "L'usager a visité l'ESMS"
          }]
        }
      }]
    }
  }]
}

```
